(function(){
const D=window.DATA,$=s=>document.querySelector(s);
const f=n=>Number(n||0).toLocaleString("id-ID"),pc=n=>(n*100).toFixed(1).replace(".",",")+"%";
const PAGES=[["dashboard","Dashboard","▦"],["ids","Sales Force (IDS)","👥"],["ds","Direct Sales (DS)","🎯"],["outlet","Outlet / PJP","🏪"],["registrasi","Registrasi Terbaru","📝"]];
const SUB={dashboard:"Pantau target, achievement, dan performa tim Branch Ambon.",ids:"Performa Sales Force / Indirect Sales per SF.",ds:"Performa Direct Sales per user code.",outlet:"Daftar outlet PJP beserta status registrasi BBB.",registrasi:"Registrasi terbaru dari form RAW Update."};
let S={};
const reset=()=>{S={q:"",sort:null,dir:1,p:0,f:"",cl:"BRANCH AMBON",view:"all"}};
const dayLbl=d=>{const x=new Date(d+"T00:00:00");return x.toLocaleDateString("id-ID",{weekday:"short"})+" "+x.getDate()};
const tgl=s=>new Date(s.replace(" ","T")).toLocaleString("id-ID",{day:"numeric",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"});
const last=a=>a[a.length-1]||0;
const opts=(arr,cur,all)=>(all?`<option value="">${all}</option>`:"")+arr.map(([v,t])=>`<option value="${v}"${v===cur?" selected":""}>${t||v}</option>`).join("");
const stat=(l,v,s,cls="")=>`<div class="tl ${cls}"><span>${l}</span><div><b>${v}</b>${s}</div></div>`;
const chip=(p,ref)=>`<span class="chip${p<ref?" dn":""}">${p<ref?"↓":"↑"} ${pc(p)}</span>`;

function table(cols,data,{fk,fvals,fall,title="Daftar Data",N=20}={}){
  let r=data.filter(x=>(!S.f||x[fk]===S.f)&&(!S.q||Object.values(x).join(" ").toLowerCase().includes(S.q)));
  if(S.sort)r=[...r].sort((a,b)=>(a[S.sort]>b[S.sort]?1:a[S.sort]<b[S.sort]?-1:0)*S.dir);
  const pages=Math.max(1,Math.ceil(r.length/N));S.p=Math.min(S.p,pages-1);
  const cell=c=>{return x=>{const v=c.v?c.v(x):x[c.k];
    if(c.t==="p")return`<td class="p"><b>${pc(v)}</b><div class="pb"><div style="width:${Math.min(100,v*100)}%"></div></div></td>`;
    if(c.t==="n")return`<td class="n">${f(v)}</td>`;if(c.t==="h")return`<td>${v}</td>`;return`<td>${v??"-"}</td>`}};
  const fc=cols.map(cell);
  return`<div class="head"><h4>${title} <small style="color:var(--mut);font-weight:400">(${f(r.length)})</small></h4><div style="display:flex;gap:8px;flex-wrap:wrap">
  <input class="sq" id="q" value="${S.q.replace(/"/g,"&quot;")}" placeholder="🔍 Search">${fk?`<select data-f>${opts(fvals.map(v=>[v]),S.f,fall)}</select>`:""}</div></div>
  <div class="tw"><table><tr>${cols.map(c=>`<th ${c.k==="chk"?"":`data-s="${c.k}"`}>${c.h}${S.sort===c.k?(S.dir>0?" ▲":" ▼"):""}</th>`).join("")}</tr>
  ${r.slice(S.p*N,S.p*N+N).map(x=>`<tr>${fc.map(g=>g(x)).join("")}</tr>`).join("")||`<tr><td colspan="${cols.length}">Tidak ada data</td></tr>`}</table></div>
  <div class="pg"><span>Halaman ${S.p+1} / ${pages}</span><span><button data-pg="-1" ${S.p<1?"disabled":""}>‹ Prev</button><button data-pg="1" ${S.p>=pages-1?"disabled":""}>Next ›</button></span></div>`;
}
const wrap=h=>`<div class="card">${h}</div>`;

function bars(a,b,labels){
  const top=Math.ceil(Math.max(...a.map((v,i)=>v+b[i]),1)/500)*500;
  const grid=[0,1,2,3,4].map(i=>`<div class="grid" style="bottom:${i*25}%"><span>${f(Math.round(top*i/4))}</span></div>`).join("");
  return`<div class="bars">${grid}${a.map((v,i)=>`<div class="bar" title="IDS ${f(v)} · DS ${f(b[i])}"><div class="t" style="height:${b[i]/top*100}%"></div><div class="b" style="height:${v/top*100}%"></div></div>`).join("")}</div>
  <div class="xl">${labels.map(l=>`<span>${l}</span>`).join("")}</div><div class="lgd"><span><s style="background:var(--red)"></s>DS</span><span><s style="background:var(--blk)"></s>IDS</span></div>`;
}

const recentCols=[{h:'<input type="checkbox">',k:"chk",t:"h",v:()=>'<input type="checkbox">'},{h:"ID Outlet / User Code",k:"ref"},{h:"Aktivitas",k:"tim",v:x=>"Registrasi BBB "+x.tim},{h:"Jumlah MSISDN",k:"n",t:"n"},{h:"Tim",k:"tim",t:"h",v:x=>`<span class="dot ${x.tim}"></span>${x.tim==="DS"?"Direct Sales":"Sales Force"}`},{h:"Tanggal",k:"ts",v:x=>tgl(x.ts)}];

const views={
dashboard(){
  const r=D.allChannel.find(x=>x.name===S.cl),br=D.allChannel[3],cls=D.allChannel.slice(0,3);
  const best=(arr,k)=>[...arr].sort((a,b)=>b[k]-a[k])[0];
  const ti=best(D.ids,"pct"),td=best(D.ds,"pct");
  return`<div class="dash">
  <div class="card hero"><div class="head" style="margin:0"><span>Total Achievement</span><select data-cl>${opts(D.allChannel.map(x=>[x.name,x.name==="BRANCH AMBON"?"Branch Ambon":x.name]),S.cl)}</select></div>
  <div class="big">${f(r.aAll)}</div>${chip(r.pAll,0)} <small style="color:var(--mut)">dari target ${f(r.tAll)}</small>
  <div class="btns"><a href="#ids">👥 Sales Force</a><a href="#ds">🎯 Direct Sales</a></div>
  <div class="wal"><small>Cluster | Total ${cls.length} cluster</small><div class="wl">${cls.map(c=>`<div><b>${c.name}</b>${f(c.aAll)}<br>${pc(c.pAll)} target<br><em class="${c.pAll<br.pAll?"dn":""}">${c.pAll<br.pAll?"Di bawah Branch":"Di atas Branch"}</em></div>`).join("")}</div></div></div>
  <div class="tiles">${stat("Total Target",f(r.tAll),`<span class="chip">All Channel</span>`,"r")}${stat("Achv IDS",f(r.aIDS),`${chip(r.pIDS,0)} <small>target ${f(r.tIDS)}</small>`)}${stat("Achv DS",f(r.aDS),`${chip(r.pDS,0)} <small>target ${f(r.tDS)}</small>`)}${stat("% Achievement",pc(r.pAll),`<small style="color:var(--mut)">${S.cl==="BRANCH AMBON"?"Branch Ambon":r.name}</small>`)}</div>
  <div class="card chart"><h4>Achievement Harian</h4><div class="hint">Registrasi BBB per hari, IDS dan DS</div>${bars(D.idsTot.daily,D.dsTot.daily,D.idsDates.map(dayLbl))}</div>
  <div class="card lim"><h4>Progress Target Branch</h4><div class="prog"><div style="width:${Math.min(100,br.pAll*100)}%"></div></div><div class="flex"><span><b>${f(br.aAll)}</b> tercapai dari</span><span>${f(br.tAll)}</span></div></div>
  <div class="card top"><div class="head"><h4>Top Performer</h4></div><div class="cards">
   <div class="cc"><span>IDS</span><div><small>Sales Force</small><b>${ti.name}</b></div><div><small>${f(ti.msisdn)} MSISDN</small><b>${pc(ti.pct)} target</b></div></div>
   <div class="cc r"><span>DS</span><div><small>Direct Sales</small><b>${td.name}</b></div><div><small>${f(td.achv)} MSISDN</small><b>${pc(td.pct)} target</b></div></div></div></div>
  <div class="card act">${table(recentCols,D.recent,{fk:"tim",fvals:["IDS","DS"],fall:"Semua Tim",title:"Registrasi Terbaru",N:5})}</div></div>`;
},
ids(){const t=D.idsTot,cl=[...new Set(D.ids.map(x=>x.cluster))];
  return`<div class="stack"><div class="stats">${stat("Jumlah SF",D.ids.length,"","r")}${stat("Achievement MSISDN",f(t.msisdn),"")}${stat("% Achievement",pc(t.msisdn/t.target),`<small>target ${f(t.target)}</small>`)}</div>`+wrap(
  table([{h:"Nama SF",k:"name"},{h:"Cluster",k:"cluster"},{h:"Jml PJP",k:"pjp",t:"n"},{h:"Target/Visit",k:"tVisit",t:"n"},{h:"Target Total",k:"target",t:"n"},{h:"Outlet Aktif",k:"outlet",t:"n"},{h:"% Outlet",k:"pOutlet",t:"p"},{h:"MSISDN",k:"msisdn",t:"n"},{h:"% Achv",k:"pct",t:"p"},{h:dayLbl(last(D.idsDates)),k:"daily",v:x=>last(x.daily),t:"n"}],D.ids,{fk:"cluster",fvals:cl,fall:"Semua Cluster",title:"Sales Force"}))+"</div>"},
ds(){const t=D.dsTot,cl=[...new Set(D.ds.map(x=>x.cluster))];
  return`<div class="stack"><div class="stats">${stat("Jumlah DS",D.ds.length,"","r")}${stat("Achievement",f(t.achv),"")}${stat("% Achievement",pc(t.achv/t.target),`<small>target ${f(t.target)}</small>`)}</div>`+wrap(
  table([{h:"Nama DS",k:"name"},{h:"User Code",k:"code"},{h:"Cluster",k:"cluster"},{h:"Target Harian",k:"dailyT",t:"n"},{h:"Target Total",k:"target",t:"n"},{h:"Achv",k:"achv",t:"n"},{h:"% Achv",k:"pct",t:"p"},{h:"Target s/d Hari Ini",k:"today",t:"n"},{h:"DRR",k:"drr",t:"p"},{h:dayLbl(last(D.dsDates)),k:"daily",v:x=>last(x.daily),t:"n"}],D.ds,{fk:"cluster",fvals:cl,fall:"Semua Cluster",title:"Direct Sales"}))+"</div>"},
outlet(){const cl=[...new Set(D.outlets.map(x=>x.cluster))].filter(Boolean),a=D.outlets.filter(x=>x.b>0).length;
  return`<div class="stack"><div class="stats">${stat("Total Outlet PJP",f(D.outlets.length),"","r")}${stat("Sudah Registrasi BBB",f(a),`<small>${pc(a/D.outlets.length)} dari outlet</small>`)}</div>`+wrap(
  table([{h:"ID Outlet",k:"id"},{h:"Nama Outlet",k:"name"},{h:"Cluster",k:"cluster"},{h:"Kabupaten",k:"kab"},{h:"Kecamatan",k:"kec"},{h:"Sales Force",k:"sf"},{h:"Hari",k:"hari"},{h:"Tipe",k:"tipe"},{h:"Prog",k:"prog"},{h:"JUM B#",k:"b",t:"n"}],D.outlets,{fk:"cluster",fvals:cl,fall:"Semua Cluster",title:"Outlet"}))+"</div>"},
registrasi(){
  return`<div class="stack"><div class="stats">${stat("Submit IDS",f(D.rawCount.IDS),"","r")}${stat("Submit DS",f(D.rawCount.DS),"")}</div>`+wrap(
  table(recentCols.slice(1),D.recent,{fk:"tim",fvals:["IDS","DS"],fall:"Semua Tim",title:"Registrasi Terbaru"}))+"</div>"}
};

function render(){
  const h=(location.hash||"#dashboard").slice(1),pg=views[h]?h:"dashboard",had=document.activeElement&&document.activeElement.id==="q";
  const hr=new Date().getHours();
  $("#hello").textContent=(hr<11?"Selamat pagi":hr<15?"Selamat siang":hr<18?"Selamat sore":"Selamat malam")+", Tim BBB Ambon";
  $("#sub").textContent=SUB[pg];
  $("nav").innerHTML=PAGES.map(([k,t,i])=>`<a href="#${k}" title="${t}" class="${k===pg?"on":""}">${i}</a>`).join("");
  $("#view").innerHTML=views[pg]();
  if(had){const q=$("#q");q.focus();q.setSelectionRange(q.value.length,q.value.length)}
}
window.addEventListener("hashchange",()=>{reset();render();scrollTo(0,0)});
document.addEventListener("input",e=>{if(e.target.id==="q"){S.q=e.target.value.toLowerCase();S.p=0;render()}});
document.addEventListener("change",e=>{const t=e.target;
  if("f"in t.dataset){S.f=t.value;S.p=0}else if("cl"in t.dataset)S.cl=t.value;else return;render()});
document.addEventListener("click",e=>{const t=e.target.closest("[data-s],[data-pg]");if(!t)return;
  if(t.dataset.s){S.dir=S.sort===t.dataset.s?-S.dir:1;S.sort=t.dataset.s}else S.p+=+t.dataset.pg;render()});
$("#mode").onclick=()=>{const d=document.body.classList.toggle("dark");$("#mode").textContent=d?"☀️":"🌙";try{localStorage.setItem("dark",d?"1":"")}catch(_){}};
try{if(localStorage.getItem("dark")){document.body.classList.add("dark");$("#mode").textContent="☀️"}}catch(_){}
$("#upd").textContent=new Date(D.updated+"T00:00:00").toLocaleDateString("id-ID",{day:"numeric",month:"long",year:"numeric"});
reset();render();
})();
