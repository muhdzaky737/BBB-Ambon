"""Baca file Excel Monitoring BBB dan hasilkan assets/js/data.js (+ data/data.json).
Pemakaian: python scripts/build_data.py path/ke/file.xlsx
Nomor MSISDN pelanggan sengaja TIDAK dimasukkan (data pribadi)."""
import sys, json, warnings, datetime as dt
from openpyxl import load_workbook
warnings.filterwarnings("ignore")
src = sys.argv[1] if len(sys.argv) > 1 else "data/Monitoring_BBB.xlsx"
wb = load_workbook(src, read_only=True, data_only=True)
rows = lambda n: list(wb[n].iter_rows(values_only=True))
num = lambda v: round(v, 4) if isinstance(v, float) else (v or 0)
iso = lambda d: d.strftime("%Y-%m-%d")

def dates(hdr, start):
    return [(i, iso(c)) for i, c in enumerate(hdr) if i >= start and isinstance(c, dt.datetime)]

allc = []
for r in rows("Summary All")[6:11]:
    if r[1]:
        allc.append(dict(name=r[1], tIDS=num(r[2]), tDS=num(r[3]), tAll=num(r[7]),
            aIDS=num(r[8]), aDS=num(r[9]), aAll=num(r[13]),
            pIDS=num(r[14]), pDS=num(r[15]), pAll=num(r[19])))

r = rows("Summary IDS"); dcols = dates(r[3], 11); ids, idsTot = [], {}
for x in r[6:]:
    if isinstance(x[0], int):
        ids.append(dict(name=x[1], cluster=x[2], pjp=num(x[3]), tVisit=num(x[4]), target=num(x[5]),
            outlet=num(x[6]), pOutlet=num(x[7]), msisdn=num(x[8]), pct=num(x[9]),
            daily=[num(x[i]) for i, _ in dcols]))
    elif x[1] == "BRANCH":
        idsTot = dict(msisdn=num(x[8]), target=num(x[5]), daily=[num(x[i]) for i, _ in dcols])
idsDates = [d for _, d in dcols]

r = rows("Summary DS"); dcols = dates(r[3], 14); ds, dsTot = [], {}
for x in r[6:]:
    if isinstance(x[0], int):
        ds.append(dict(name=x[3], code=x[2], cluster=x[5], dailyT=num(x[6]), target=num(x[7]),
            achv=num(x[8]), pct=num(x[9]), today=num(x[10]), drr=num(x[12]),
            daily=[num(x[i]) for i, _ in dcols]))
    elif x[4] == "BRANCH":
        dsTot = dict(achv=num(x[8]), target=num(x[7]), daily=[num(x[i]) for i, _ in dcols])
dsDates = [d for _, d in dcols]

outlets = [dict(id=x[0], name=x[2], area=x[3], cluster=x[6], kab=x[7], kec=x[8], sf=x[12],
    hari=x[13], tipe=x[17], prog=x[18], b=num(x[19]))
    for x in rows("RAW PJP")[1:] if x[0]]

raw = [x for x in rows("RAW Update")[1:] if x[0]]
raw.sort(key=lambda x: x[0], reverse=True)
recent = [dict(ts=x[0].strftime("%Y-%m-%d %H:%M"), tim="DS" if x[1] == "Direct Sales" else "IDS",
    ref=str((x[4] if x[1] == "Direct Sales" else x[2]) or "-"), n=int((x[7] or 0) + (x[8] or 0)))
    for x in raw[:300]]
rawCount = dict(IDS=sum(1 for x in raw if x[1] != "Direct Sales"), DS=sum(1 for x in raw if x[1] == "Direct Sales"))

data = dict(title="Monitoring BBB Branch Ambon", updated=iso(raw[0][0]) if raw else "",
    allChannel=allc, ids=ids, idsTot=idsTot, idsDates=idsDates, ds=ds, dsTot=dsTot, dsDates=dsDates,
    outlets=outlets, recent=recent, rawCount=rawCount)
js = json.dumps(data, ensure_ascii=False, separators=(",", ":"), default=str)
open("assets/js/data.js", "w", encoding="utf-8").write("window.DATA=" + js + ";")
open("data/data.json", "w", encoding="utf-8").write(js)
print("OK", {k: len(v) for k, v in data.items() if isinstance(v, list)}, len(js)//1024, "KB")
